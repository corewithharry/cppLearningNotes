#include "handler.h"
#include <cstdlib>
bool IdHandler::Test(string token, bool forInvoke)
{
	//TODO
}
shared_ptr<Expr> IdHandler::IdFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	//TODO
}

shared_ptr<Expr> NumberHandler::NumberFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	//TODO
}
bool NumberHandler::Test(string token, bool forInvoke)
{
	//TODO
}

bool BinaryHandler::Test(string token, bool forInvoke)
{
	//TODO
}
shared_ptr<Expr>BinaryHandler::BinaryFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	//TODO
}

shared_ptr<Expr> InvokeHandler::InvokeFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	//TODO
}
bool InvokeHandler::Test(string token, bool forInvoke)
{
	//TODO
}

