#pragma once
#include "Expr.h"
#include <cstring>
char GetOp(BinaryOperator B);
bool Is(const char*& Stream, const char* Text);
